<template>
    <div class="navbar">
        <!-- <el-button @click="logout" style=" height: 40px; margin-top: 7px; margin-right: 30px; float: right">
            退出登录
        </el-button> -->
    </div>
</template>

<script lang="ts" setup>


</script>

<style lang="scss" scoped>
.navbar {
    height: 100%;
    overflow: hidden;
    position: relative;
    background: #0b72bf;
    box-shadow: 0 1px 4px rgba(0, 21, 41, 0.08);
}
</style>