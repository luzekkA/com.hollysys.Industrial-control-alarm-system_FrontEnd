<template>
  <div class="text-center" style="font-size: 130px">404</div>
</template>
